TEAM PHOTOS PLACEMENT GUIDE
============================

Please place the team member photos in this directory with the following filenames:

1. beena-k.jpg - Mrs Beena K (Project Guide)
   - Photo: Woman in pink saree with gold embroidery (Image 1)

2. sindhu.jpg - Sindhu (Frontend Developer - UI/UX + Client-Side)
   - Photo: Woman in white kurta with pink/silver embroidery (Image 2)

3. tejashwini-sr.jpg - Tejashwini S R (Backend Developer - Server + Database)
   - Photo: Woman in black outfit standing in park (Image 3)

4. vidya-k.jpg - Vidya K (Full-Stack / DevOps & Integrator)
   - Photo: Woman in black t-shirt with "MELANIN QUEEN" text (Image 4)

IMAGE REQUIREMENTS:
- Format: JPG or PNG
- Recommended size: 400x400px or larger (square aspect ratio)
- File size: Under 500KB per image for web optimization

If images are not found, placeholder images will be displayed automatically.

