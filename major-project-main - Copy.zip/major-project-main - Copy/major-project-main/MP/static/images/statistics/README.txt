STATISTICS IMAGES PLACEMENT GUIDE
==================================

Please place the following dataset and training-related images in this directory:

1. dataset-overview.jpg
   - Description: Overview visualization of the training dataset
   - Suggested content: Dataset distribution chart, sample data visualization, or dataset statistics infographic
   - Recommended size: 800x400px or larger
   - Format: JPG or PNG

2. training-curve.jpg
   - Description: Training curve visualization showing model performance
   - Suggested content: Graph showing training vs validation accuracy/loss over epochs
   - Recommended size: 600x400px or larger
   - Format: JPG or PNG

IMAGE REQUIREMENTS:
- Format: JPG or PNG
- Recommended size: 600-800px width
- File size: Under 500KB per image for web optimization
- All images should be relevant to machine learning model training and datasets

If images are not found, they will be hidden automatically (onerror handler).

ALTERNATIVE:
If you have images on your PC, you can:
1. Copy them to this directory with the exact filenames above
2. Or update the image paths in estatistics.html to point to your local images

