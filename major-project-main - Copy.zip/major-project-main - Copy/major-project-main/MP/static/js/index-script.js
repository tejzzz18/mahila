// Mahila Suraksha Nyayavani — Homepage Scripts
// Progressive enhancement — works without JS

(function() {
  'use strict';

  // Navigation Toggle
  const navToggle = document.getElementById('navToggle');
  const navLinks = document.getElementById('navLinks');
  
  if (navToggle && navLinks) {
    navToggle.addEventListener('click', function() {
      const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', !isExpanded);
      navLinks.setAttribute('aria-expanded', !isExpanded);
    });
  }

  // Stories Slider
  const storiesTrack = document.getElementById('storiesTrack');
  const prevBtn = document.getElementById('prevBtn');
  const nextBtn = document.getElementById('nextBtn');
  let currentSlide = 0;
  
  if (storiesTrack) {
    const slides = storiesTrack.querySelectorAll('.story-slide');
    const totalSlides = slides.length;
    
    function showSlide(index) {
      slides.forEach((slide, i) => {
        slide.classList.toggle('active', i === index);
      });
      currentSlide = index;
    }
    
    function nextSlide() {
      const next = (currentSlide + 1) % totalSlides;
      showSlide(next);
    }
    
    function prevSlide() {
      const prev = (currentSlide - 1 + totalSlides) % totalSlides;
      showSlide(prev);
    }
    
    if (nextBtn) {
      nextBtn.addEventListener('click', nextSlide);
    }
    
    if (prevBtn) {
      prevBtn.addEventListener('click', prevSlide);
    }
    
    // Auto-play (pause on hover)
    let autoPlayInterval;
    
    function startAutoPlay() {
      autoPlayInterval = setInterval(nextSlide, 5000);
    }
    
    function stopAutoPlay() {
      clearInterval(autoPlayInterval);
    }
    
    if (storiesTrack) {
      storiesTrack.addEventListener('mouseenter', stopAutoPlay);
      storiesTrack.addEventListener('mouseleave', startAutoPlay);
      startAutoPlay();
    }
  }

  // Chatbot Panel
  const chatbotBtn = document.getElementById('chatbotBtn');
  const chatbotPanel = document.getElementById('chatbotPanel');
  const chatbotClose = document.getElementById('chatbotClose');
  const chatbotInput = document.getElementById('chatbotInput');
  const chatbotSend = document.getElementById('chatbotSend');
  const chatbotMessages = document.getElementById('chatbotMessages');
  
  function openChatbot() {
    if (chatbotPanel) {
      chatbotPanel.setAttribute('aria-hidden', 'false');
      chatbotPanel.setAttribute('aria-modal', 'true');
      if (chatbotInput) {
        chatbotInput.focus();
      }
    }
  }
  
  function closeChatbot() {
    if (chatbotPanel) {
      chatbotPanel.setAttribute('aria-hidden', 'true');
      chatbotPanel.setAttribute('aria-modal', 'false');
    }
  }
  
  if (chatbotBtn) {
    chatbotBtn.addEventListener('click', openChatbot);
  }
  
  if (chatbotClose) {
    chatbotClose.addEventListener('click', closeChatbot);
  }
  
  // Close on Escape key
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && chatbotPanel && chatbotPanel.getAttribute('aria-hidden') === 'false') {
      closeChatbot();
    }
  });
  
  // Chatbot message sending (UI only)
  function sendMessage() {
    if (!chatbotInput || !chatbotMessages) return;
    
    const message = chatbotInput.value.trim();
    if (!message) return;
    
    // Add user message
    const userMsg = document.createElement('div');
    userMsg.className = 'chatbot-message user';
    userMsg.innerHTML = `<p>${message}</p>`;
    chatbotMessages.appendChild(userMsg);
    
    // Clear input
    chatbotInput.value = '';
    
    // Scroll to bottom
    chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
    
    // Simulate bot response (UI only)
    setTimeout(function() {
      const botMsg = document.createElement('div');
      botMsg.className = 'chatbot-message bot';
      botMsg.innerHTML = '<p>Thank you for your message. For immediate help, please call the helpline numbers listed in the footer, or use the SOS button.</p>';
      chatbotMessages.appendChild(botMsg);
      chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
    }, 1000);
  }
  
  if (chatbotSend) {
    chatbotSend.addEventListener('click', sendMessage);
  }
  
  if (chatbotInput) {
    chatbotInput.addEventListener('keypress', function(e) {
      if (e.key === 'Enter') {
        sendMessage();
      }
    });
  }

  // Smooth scroll for anchor links
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      const href = this.getAttribute('href');
      if (href === '#' || href === '#home') {
        e.preventDefault();
        window.scrollTo({ top: 0, behavior: 'smooth' });
        return;
      }
      
      const target = document.querySelector(href);
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

  // Form submission (prevent default, show message)
  const appointmentForm = document.querySelector('.appointment-form');
  if (appointmentForm) {
    appointmentForm.addEventListener('submit', function(e) {
      e.preventDefault();
      alert('Thank you for your request. Our team will contact you shortly to confirm your appointment slot.');
      this.reset();
    });
  }
})();

