// Navbar Dropdown Menu Functionality
// Handles dropdown open/close on click and hover

(function() {
  'use strict';

  const dropdowns = document.querySelectorAll('.nav-dropdown');
  
  dropdowns.forEach(function(dropdown) {
    const toggle = dropdown.querySelector('.dropdown-toggle');
    const menu = dropdown.querySelector('.dropdown-menu');
    
    if (!toggle || !menu) return;
    
    // Check if toggle has href="#" (like Inspo) or a real link (like Articles, About Us)
    const hasRealLink = toggle.getAttribute('href') && toggle.getAttribute('href') !== '#';
    
    // Click handler - behavior depends on screen size and link type
    toggle.addEventListener('click', function(e) {
      const isMobile = window.innerWidth <= 720;
      
      // On mobile OR if link is "#" (Inspo), toggle dropdown
      if (isMobile || !hasRealLink) {
        e.preventDefault();
        const isOpen = dropdown.classList.contains('open');
        
        // Close all other dropdowns
        dropdowns.forEach(function(other) {
          if (other !== dropdown) {
            other.classList.remove('open');
            const otherToggle = other.querySelector('.dropdown-toggle');
            if (otherToggle) {
              otherToggle.setAttribute('aria-expanded', 'false');
            }
          }
        });
        
        // Toggle current dropdown
        if (isOpen) {
          dropdown.classList.remove('open');
          toggle.setAttribute('aria-expanded', 'false');
        } else {
          dropdown.classList.add('open');
          toggle.setAttribute('aria-expanded', 'true');
        }
      }
      // On desktop with real links, allow normal navigation (hover shows dropdown)
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
      if (!dropdown.contains(e.target)) {
        dropdown.classList.remove('open');
        toggle.setAttribute('aria-expanded', 'false');
      }
    });
    
    // Keyboard navigation
    toggle.addEventListener('keydown', function(e) {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        toggle.click();
      }
    });
    
    // Close on Escape key
    document.addEventListener('keydown', function(e) {
      if (e.key === 'Escape' && dropdown.classList.contains('open')) {
        dropdown.classList.remove('open');
        toggle.setAttribute('aria-expanded', 'false');
        toggle.focus();
      }
    });
  });
  
  // Close dropdowns when window loses focus (optional)
  window.addEventListener('blur', function() {
    dropdowns.forEach(function(dropdown) {
      dropdown.classList.remove('open');
      const toggle = dropdown.querySelector('.dropdown-toggle');
      if (toggle) {
        toggle.setAttribute('aria-expanded', 'false');
      }
    });
  });
  
  // Language dropdown functionality
  const langDropdown = document.querySelector('.lang-dropdown');
  if (langDropdown) {
    const langToggle = langDropdown.querySelector('.lang-toggle');
    const langMenu = langDropdown.querySelector('.lang-menu');
    
    if (langToggle && langMenu) {
      langToggle.addEventListener('click', function(e) {
        e.preventDefault();
        const isOpen = langDropdown.classList.contains('open');
        
        if (isOpen) {
          langDropdown.classList.remove('open');
          langToggle.setAttribute('aria-expanded', 'false');
        } else {
          langDropdown.classList.add('open');
          langToggle.setAttribute('aria-expanded', 'true');
        }
      });
      
      // Close on outside click
      document.addEventListener('click', function(e) {
        if (!langDropdown.contains(e.target)) {
          langDropdown.classList.remove('open');
          langToggle.setAttribute('aria-expanded', 'false');
        }
      });
    }
  }
})();

