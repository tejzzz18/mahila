import os
import pathlib
import traceback
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from werkzeug.utils import secure_filename
from pymongo import MongoClient
from pymongo.errors import (
    PyMongoError,
    ServerSelectionTimeoutError,
    DuplicateKeyError,
    WriteError,
)
from dotenv import load_dotenv

# ------------------------------
# Load environment variables
# ------------------------------
load_dotenv()

MONGO_URI = os.getenv("MONGO_URI")
DB_NAME = os.getenv("MONGO_DBNAME", "mahila_reports")
UPLOAD_FOLDER = os.getenv("UPLOAD_FOLDER", "static/uploads")
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif", "pdf"}

# ensure uploads folder exists
pathlib.Path(UPLOAD_FOLDER).mkdir(parents=True, exist_ok=True)

# ------------------------------
# Flask Setup
# ------------------------------
app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "replace_this_later")
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = 50 * 1024 * 1024  # 50MB


# ------------------------------
# MongoDB Connection
# ------------------------------
if not MONGO_URI:
    raise RuntimeError("MONGO_URI not set in .env")

client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=5000)

try:
    info = client.server_info()
    app.logger.info("Connected to MongoDB version: %s", info.get("version"))
except Exception as e:
    app.logger.error("MongoDB connection failed: %s", e)
    raise

db = client[DB_NAME]
reports_col = db["reports"]


# ------------------------------
# Helper Functions
# ------------------------------
def allowed_file(filename: str) -> bool:
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def save_uploaded_files(file_list):
    saved_rel_paths = []

    for f in file_list:
        if not f or not f.filename:
            continue

        if not allowed_file(f.filename):
            app.logger.warning("Skipped unsupported file: %s", f.filename)
            continue

        safe_name = secure_filename(f.filename)
        ts = datetime.utcnow().strftime("%Y%m%d%H%M%S%f")
        final_name = f"{ts}_{safe_name}"

        static_dir = os.path.join(app.root_path, "static")
        upload_dir = os.path.join(app.root_path, UPLOAD_FOLDER)

        os.makedirs(upload_dir, exist_ok=True)

        file_path = os.path.join(upload_dir, final_name)
        try:
            f.save(file_path)
            rel_path = os.path.relpath(file_path, static_dir).replace("\\", "/")
            saved_rel_paths.append(rel_path)
        except Exception as e:
            app.logger.error("File save failed: %s", e)

    return saved_rel_paths


# ------------------------------
# Global Year
# ------------------------------
@app.context_processor
def inject_year():
    return {"current_year": datetime.utcnow().year}


# ------------------------------
# ENGLISH ROUTES
# ------------------------------

@app.route("/")
def home():
    return render_template("ehome.html")

@app.route("/articles")
def articles():
    return render_template("earticle.html")

@app.route("/articles/physical")
def physical_article():
    return render_template("physical.html")

@app.route("/articles/emotional")
def emotional_article():
    return render_template("emotional.html")

@app.route("/articles/digital")
def digital_article():
    return render_template("d.html")

@app.route("/about")
def about():
    return render_template("eaboutus.html")

@app.route("/contact", methods=["GET", "POST"])
def contact():
    if request.method == "POST":
        if not request.form.get("name") or not request.form.get("email") or not request.form.get("message"):
            flash("Please fill all fields.", "error")
            return redirect(url_for("contact"))
        flash("Message received!", "success")
    return render_template("econtact.html")

@app.route("/help")
def help_page():
    return render_template("ehelp.html")


# ------------------------------
# FIXED STORIES ENDPOINT
# ------------------------------
@app.route("/stories")
def stories():
    return render_template("ytvideos.html")


# ------------------------------
# SUBMIT REPORT
# ------------------------------
@app.route("/submit_report", methods=["POST"])
def submit_report():
    try:
        name = request.form.get("name", "").strip()
        aadhar = request.form.get("aadhar", "").strip()
        contact = request.form.get("contact", "").strip()
        category = request.form.get("category", "").strip()
        location = request.form.get("location", "").strip()
        incident = request.form.get("incident", "").strip()

        if not (name and aadhar and contact and category and location and incident):
            return jsonify({"success": False, "error": "All fields are required."}), 400

        if not aadhar.isdigit() or len(aadhar) != 12:
            return jsonify({"success": False, "error": "Invalid Aadhaar number."}), 400

        files = request.files.getlist("evidence")
        saved_files = save_uploaded_files(files)

        report_doc = {
            "name": name,
            "aadhar": aadhar,
            "contact": contact,
            "category": category,
            "location": location,
            "incident": incident,
            "evidence_files": saved_files,
            "language": "english",
            "created_at": datetime.utcnow(),
        }

        inserted = reports_col.insert_one(report_doc)
        return jsonify({"success": True, "id": str(inserted.inserted_id)}), 201

    except Exception as e:
        app.logger.error("Report submit error: %s", e)
        app.logger.error(traceback.format_exc())
        return jsonify({"success": False, "error": "Server error."}), 500


@app.route("/report")
def report():
    return render_template("ereport.html")


@app.route("/selfdefence")
def selfdefence():
    return render_template("evideos.html")

@app.route("/chatbot")
def chatbot():
    return render_template("chatbot.html")

@app.route("/statistics")
def statistics():
    return render_template("estatistics.html")

@app.route("/counselling")
def counselling():
    return render_template("ecounselling.html")

@app.route("/latest-news")
def latest_news():
    return render_template("enews.html")

@app.route("/feedback", methods=["GET", "POST"])
def feedback():
    if request.method == "POST":
        flash("Thank you for your feedback!", "success")
    return render_template("efeedback.html")


# ------------------------------
# KANNADA ROUTES
# ------------------------------

@app.route("/kannada")
def kannada_home():
    return render_template("khome.html")

@app.route("/karticle")
def karticle():
    return render_template("karticle.html")

@app.route("/kabout")
def kabout():
    return render_template("kaboutus.html")

@app.route("/kcontact", methods=["GET", "POST"])
def kcontact():
    if request.method == "POST":
        flash("ನಿಮ್ಮ ಸಂದೇಶ ಸ್ವೀಕರಿಸಲಾಗಿದೆ!", "success")
    return render_template("kcontact.html")

@app.route("/khelp")
def khelp():
    return render_template("khelp.html")

@app.route("/submit_kreport", methods=["POST"])
def submit_kreport():
    try:
        name = request.form.get("name", "").strip()
        aadhar = request.form.get("aadhar", "").strip()
        contact = request.form.get("contact", "").strip()
        category = request.form.get("category", "").strip()
        location = request.form.get("location", "").strip()
        incident = request.form.get("incident", "").strip()

        if not (name and aadhar and contact and category and location and incident):
            flash("ಎಲ್ಲಾ ಕ್ಷೇತ್ರಗಳು ಅಗತ್ಯವಿದೆ.", "error")
            return redirect(url_for("kreport"))

        if not aadhar.isdigit() or len(aadhar) != 12:
            flash("ಮಾನ್ಯವಾದ 12 ಅಂಕಿಯ ಆಧಾರ್ ನಮೂದಿಸಿ.", "error")
            return redirect(url_for("kreport"))

        files = request.files.getlist("evidence")
        saved_files = save_uploaded_files(files)

        report_doc = {
            "name": name,
            "aadhar": aadhar,
            "contact": contact,
            "category": category,
            "location": location,
            "incident": incident,
            "language": "kannada",
            "created_at": datetime.utcnow(),
            "evidence_files": saved_files,
        }

        reports_col.insert_one(report_doc)
        flash("ಘಟನೆ ಯಶಸ್ವಿಯಾಗಿ ಸಲ್ಲಿಸಲಾಗಿದೆ.", "success")
        return redirect(url_for("kreport"))

    except Exception as e:
        app.logger.error("Kannada report error: %s", e)
        flash("ಸರ್ವರ್ ದೋಷ.", "error")
        return redirect(url_for("kreport"))

@app.route("/kreport")
def kreport():
    return render_template("kreport.html")

@app.route("/kselfdefence")
def kselfdefence():
    return render_template("kvideos.html")

@app.route("/kfeedback", methods=["GET", "POST"])
def kfeedback():
    if request.method == "POST":
        flash("ಧನ್ಯವಾದಗಳು!", "success")
    return render_template("kfeedback.html")


# ------------------------------
# Server Run
# ------------------------------
if __name__ == "__main__":
    app.run(debug=True)
