# test_mongo_connection.py
import os
from pymongo import MongoClient
from dotenv import load_dotenv

# load .env
load_dotenv()

MONGO_URI = os.getenv("MONGO_URI")
DB_NAME = os.getenv("MONGO_DBNAME", "mahila_reports")

print("🔍 Checking MongoDB Connection...")
print("MONGO_URI found:", bool(MONGO_URI))

if not MONGO_URI:
    print("❌ ERROR: MONGO_URI is not set in .env")
    exit()

try:
    client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=5000)
    print("⏳ Connecting to server...")
    
    # This will fail immediately if credentials or IP are wrong
    server_info = client.server_info()
    print("✅ Connected! MongoDB Version:", server_info["version"])

    # Select the DB
    db = client[DB_NAME]
    
    # Count documents in reports collection
    count = db.reports.count_documents({})
    print(f"📁 Database '{DB_NAME}' connected.")
    print(f"📝 'reports' collection document count: {count}")

except Exception as e:
    print("❌ Connection failed:")
    print(str(e))
