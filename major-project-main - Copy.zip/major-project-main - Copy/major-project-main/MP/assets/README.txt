ASSETS FOLDER — REPLACEMENT INSTRUCTIONS
==========================================

This folder contains placeholder SVG images that should be replaced with actual optimized images.

REPLACEMENT GUIDELINES:
-----------------------

1. hero-illustration.svg
   - Current: Placeholder SVG (500x600px)
   - Replace with: Professional illustration of a woman standing confidently with a shield
   - Recommended sources: Unsplash, Midjourney, DALL·E
   - Format: SVG or WebP (optimized)
   - Size: 500x600px or larger (will scale down)
   - Alt text already set: "Illustration: woman standing confidently with shield"

2. advocate-avatar.svg
   - Current: Placeholder SVG (200x200px)
   - Replace with: Professional headshot photo of Advocate Arpitha
   - Format: JPG/WebP (square, 200x200px minimum)
   - Recommended: Professional portrait, neutral background
   - File path: assets/advocate-avatar.svg (or .jpg/.webp — update HTML if changing format)

3. chatbot-avatar.svg
   - Current: Placeholder SVG (100x100px)
   - Replace with: Friendly AI chatbot icon/avatar
   - Format: SVG (preferred) or PNG/WebP
   - Style: Simple, friendly, approachable design
   - Size: 100x100px

4. icons/ folder
   - Contains inline SVG icons used in action chips
   - Current: Inline SVG in HTML (no separate files needed)
   - Optional: Replace with icon library (Font Awesome, Heroicons, etc.)
   - If using external library, update HTML class names accordingly

IMAGE OPTIMIZATION TIPS:
------------------------
- Use WebP format for photos (better compression)
- Use SVG for illustrations and icons (scalable, small file size)
- Compress images before adding (use tools like TinyPNG, Squoosh)
- Ensure images are properly sized (don't use 2000px images for 200px displays)
- All images should have appropriate alt text (already included in HTML)

RECOMMENDED SOURCES:
--------------------
- Unsplash: https://unsplash.com (free, high-quality photos)
- Midjourney: AI-generated illustrations
- DALL·E: AI-generated illustrations
- Flaticon: https://www.flaticon.com (icons)

FILE STRUCTURE:
---------------
assets/
  ├── hero-illustration.svg (or .webp)
  ├── advocate-avatar.svg (or .jpg/.webp)
  ├── chatbot-avatar.svg
  ├── icons/ (optional, if using separate icon files)
  └── README.txt (this file)

NOTES:
------
- After replacing images, test the page to ensure all images load correctly
- Update file extensions in HTML if changing from SVG to JPG/WebP
- Maintain aspect ratios when resizing images
- Keep file names consistent with HTML references

